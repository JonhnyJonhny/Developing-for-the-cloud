def lambda_handler(event, context):
 print('Report Generated!)
 return 'Success'